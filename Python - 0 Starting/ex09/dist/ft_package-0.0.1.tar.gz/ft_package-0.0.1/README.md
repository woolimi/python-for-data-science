## Build

```
python setup.py sdist bdist_wheel
```

## Install

```
pip install ./dist/ft_package-0.0.1.tar.gz
```

## Test

```
python tester.py
```
